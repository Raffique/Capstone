# PULMONARY EMBOLISM DETECTOR

Capstone finalproject implementation of nueural networks:

```
CNN
CNN-LSTM
FCRN
```

RSNA-STR-PE DATASET FROM KAGGLE

```python
classes = ['{}_pe_present_on_image',
 '{}_negative_exam_for_pe',
 '{}_indeterminate',
 '{}_chronic_pe',
 '{}_acute_and_chronic_pe',
 '{}_central_pe',
 '{}_leftsided_pe',
 '{}_rightsided_pe',
 '{}_rv_lv_ratio_gte_1',
 '{}_rv_lv_ratio_lt_1',
]
```

